/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.GamerStore.service.impl;

import com.GamerStore.dao.FacturaDao;
import com.GamerStore.dao.ProductoDao;
import com.GamerStore.dao.VentaDao;
import com.GamerStore.domain.Factura;
import com.GamerStore.domain.Item;
import com.GamerStore.domain.Producto;
import com.GamerStore.domain.Venta;
import com.GamerStore.service.ItemService;
import static com.GamerStore.service.ItemService.listaItems;
import java.util.List;
import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Service
public class ItemServiceImpl implements ItemService {

    @Override
    public List<Item> get() {
        return listaItems;
    }

    //Se usa en el addCarrito... agrega un elemento
    @Override
    public void save(Item item) {
        boolean existe = false;
        for (Item i : listaItems) {
            //Busca si ya existe el producto en el carrito
            if (Objects.equals(i.getIdProducto(), item.getIdProducto())) {
                //Valida si aún puede colocar un item adicional -según existencias-
                if (i.getCantidad() < item.getExistencias()) {
                    //Incrementa en 1 la cantidad de elementos
                    i.setCantidad(i.getCantidad() + 1);
                }
                existe = true;
                break;
            }
        }
        if (!existe) {
            //Si no está el producto en el carrito se agrega cantidad = 1.
            item.setCantidad(1);
            listaItems.add(item);
        }
    }

    //Se usa para eliminar un producto del carrito
    @Override
    public void delete(Item item) {
        var posicion = -1;
        var existe = false;
        for (Item i : listaItems) {
            ++posicion;
            if (Objects.equals(i.getIdProducto(), item.getIdProducto())) {
                existe = true;
                break;
            }
        }
        if (existe) {
            listaItems.remove(posicion);
        }
    }

    @Override
    public Item get(Item item) {
        for (Item i : listaItems) {
            if (Objects.equals(i.getIdProducto(), item.getIdProducto())) {
                return i;
            }
        }
        return null;
    }

    //Se usa en la página para actualizar la cantidad de productos
    @Override
    public void actualiza(Item item) {
        for (Item i : listaItems) {
            if (Objects.equals(i.getIdProducto(), item.getIdProducto())) {
                i.setCantidad(item.getCantidad());
                break;
            }
        }
    }

    @Autowired
    private FacturaDao facturaDao;

    @Autowired
    private VentaDao ventaDao;

    @Autowired
    private ProductoDao productoDao;

    @Override
    public void facturar() {
        // Obtener el usuario autenticado
        String username = null;
        var principal = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getPrincipal();
        if (principal instanceof UserDetails userDetails) {
            username = userDetails.getUsername();
        } else {
            username = principal.toString();
        }

        // Si el nombre de usuario es nulo o está en blanco, salir
        if (username == null || username.isBlank()) {
            return;
        }

        // Crear la factura utilizando únicamente el nombre de usuario
        Factura factura = new Factura();
        factura = facturaDao.save(factura);

        double total = 0;
        for (Item i : listaItems) {
            System.out.println("Producto: " + i.getDescripcion()
                    + " Cantidad: " + i.getCantidad()
                    + " Total: " + i.getPrecio() * i.getCantidad());

            Venta venta = new Venta(factura.getIdFactura(),
                    i.getIdProducto(),
                    i.getPrecio(),
                    i.getCantidad());
            ventaDao.save(venta);

            Producto producto = productoDao.getReferenceById(i.getIdProducto());
            producto.setExistencias(producto.getExistencias() - i.getCantidad());
            productoDao.save(producto);

            total += i.getPrecio() * i.getCantidad();
        }

        factura.setTotal(total);
        facturaDao.save(factura);
        listaItems.clear();
    }

}
