package com.GamerStore.service;

import com.GamerStore.domain.MetodoPago;
import java.util.List;

public interface MetodoPagoService {
    List<MetodoPago> getMetodosPago(boolean activos);
    MetodoPago getMetodoPago(MetodoPago metodoPago);
    void save(MetodoPago metodoPago);
    void delete(MetodoPago metodoPago);
}

