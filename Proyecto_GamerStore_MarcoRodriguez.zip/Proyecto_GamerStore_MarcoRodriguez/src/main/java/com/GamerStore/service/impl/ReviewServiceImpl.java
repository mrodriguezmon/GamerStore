
package com.GamerStore.service.impl;

import com.GamerStore.dao.ReviewDao;
import com.GamerStore.domain.Review;
import com.GamerStore.service.ReviewService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ReviewServiceImpl implements ReviewService {

    @Autowired
    private ReviewDao reviewDao;

    @Override
    @Transactional(readOnly = true)
    public Review getReview(Review review) {
        return reviewDao.findById(review.getIdReview()).orElse(null);
    }

    @Override
    @Transactional
    public void save(Review review) {
        reviewDao.save(review);
    }

    @Override
    @Transactional
    public void delete(Review review) {
        reviewDao.delete(review);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Review> getReview(boolean activos) {
        return (List<Review>) reviewDao.findAll();
    }
}
