package com.GamerStore.service;

import com.GamerStore.domain.Descuento;
import java.util.List;

public interface DescuentoService {
    List<Descuento> getDescuentos(boolean activos);
    Descuento getDescuento(Descuento descuento);
    void save(Descuento descuento);
    void delete(Descuento descuento);
}

