package com.GamerStore.service.impl;

import com.GamerStore.dao.MetodoPagoDao;
import com.GamerStore.domain.MetodoPago;
import com.GamerStore.service.MetodoPagoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MetodoPagoServiceImpl implements MetodoPagoService {

    @Autowired
    private MetodoPagoDao metodoPagoDao;

    @Override
    @Transactional(readOnly = true)
    public List<MetodoPago> getMetodosPago(boolean activos) {
        return (List<MetodoPago>) metodoPagoDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public MetodoPago getMetodoPago(MetodoPago metodoPago) {
        return metodoPagoDao.findById(metodoPago.getIdMetodoPago()).orElse(null);
    }

    @Override
    @Transactional
    public void save(MetodoPago metodoPago) {
        metodoPagoDao.save(metodoPago);
    }

    @Override
    @Transactional
    public void delete(MetodoPago metodoPago) {
        metodoPagoDao.delete(metodoPago);
    }
}
