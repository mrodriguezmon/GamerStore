package com.GamerStore.service;

import com.GamerStore.domain.Review;
import java.util.List;

public interface ReviewService {

    List<Review> getReview(boolean activos);
    Review getReview(Review review);
    void save(Review review);
    void delete(Review review);

}
