package com.GamerStore.dao;

import com.GamerStore.domain.Descuento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DescuentoDao extends JpaRepository<Descuento, Long> {
}

