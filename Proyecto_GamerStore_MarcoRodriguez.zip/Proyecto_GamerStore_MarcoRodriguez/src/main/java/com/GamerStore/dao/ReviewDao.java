
package com.GamerStore.dao;

import com.GamerStore.domain.Review;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewDao extends JpaRepository <Review, Long> {
    
}