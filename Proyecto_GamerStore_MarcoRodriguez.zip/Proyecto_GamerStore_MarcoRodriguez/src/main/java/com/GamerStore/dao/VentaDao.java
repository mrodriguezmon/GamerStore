
package com.GamerStore.dao;

import com.GamerStore.domain.Venta;
import org.springframework.data.jpa.repository.JpaRepository;


public interface VentaDao extends JpaRepository<Venta, Long>{
    
}
