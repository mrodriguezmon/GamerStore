package com.GamerStore.dao;

import com.GamerStore.domain.MetodoPago;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetodoPagoDao extends JpaRepository<MetodoPago, Long> {
}

