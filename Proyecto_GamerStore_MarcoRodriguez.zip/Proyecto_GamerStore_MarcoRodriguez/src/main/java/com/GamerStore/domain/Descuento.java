
package com.GamerStore.domain;

import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;

@Data
@Entity
@Table(name="descuento")
public class Descuento implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_descuento")
    private Long idDescuento;

    @Column(nullable = false)
    private BigDecimal porcentaje;  // Porcentaje de descuento

    @Column(nullable = false)
    private String descripcion;  // Descripción del descuento

    @ManyToOne
    @JoinColumn(name = "id_producto")
    private Producto producto;
}

