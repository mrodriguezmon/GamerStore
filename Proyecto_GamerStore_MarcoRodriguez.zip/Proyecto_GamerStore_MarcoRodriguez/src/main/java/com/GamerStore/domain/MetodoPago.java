package com.GamerStore.domain;

import jakarta.persistence.*;
import java.io.Serializable;
import lombok.Data;

@Data
@Entity
@Table(name="metodopago")
public class MetodoPago implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_metodopago")
    private Long idMetodoPago;

    private String tipo;  // Ej. "Tarjeta de crédito", "PayPal"
    private String numero;  // Ej. Número de tarjeta de crédito enmascarado
    private String fechaVencimiento;
    private String nombreTitular;
    
    // @ManyToOne
    // @JoinColumn(name = "id_cliente")
    // private Cliente cliente;
}

