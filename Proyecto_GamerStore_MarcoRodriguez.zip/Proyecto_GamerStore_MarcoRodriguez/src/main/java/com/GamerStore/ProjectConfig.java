package com.GamerStore;

import java.util.Locale;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

@Configuration
public class ProjectConfig implements WebMvcConfigurer {

    @Bean
    public LocaleResolver localeResolver() {
        var slr = new SessionLocaleResolver();
        slr.setDefaultLocale(Locale.getDefault());
        slr.setLocaleAttributeName("session.current.timezone");
        slr.setTimeZoneAttributeName("session.current.timezone");
        return slr;
    }

    @Bean
    public LocaleChangeInterceptor localeChangeInterceptor() {
        var lci = new LocaleChangeInterceptor();
        lci.setParamName("lang");
        return lci;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registro) {
        registro.addInterceptor(localeChangeInterceptor());
    }

    @Bean("meesageSource")
    public MessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        messageSource.setBasenames("messages");
        messageSource.setDefaultEncoding("UT-8");
        return messageSource;
    }
    
        @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("index");
        registry.addViewController("/index").setViewName("index");
        registry.addViewController("/login").setViewName("login");
        registry.addViewController("/registro/nuevo").setViewName("/registro/nuevo");
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests((request) -> request
                .requestMatchers("/", "/index", "/errores/**",
                        "/carrito/**", "/soporte/**", "/cliente/**",
                        "/registro/**","/review/**","/metodopago/**", "/js/**","/descuento/**", "/webjars/**")
                .permitAll()
                .requestMatchers("/producto/nuevo", "/producto/guardar",
                        "/producto/modificar/**", "/producto/eliminar/**",
                        "/categoria/nuevo", "/categoria/guardar",
                        "/categoria/modificar/**", "/categoria/eliminar/**",
                        "/usuario/nuevo", "/usuario/guardar",
                        "/cliente/modificar/**", "/cliente/eliminar/**",
                        "/reportes/**",
                        "/review/modificar/**","/review/eliminar/**",
                        "/soporte/modificar/**","/soporte/eliminar/**",
                        "/metodopago/modificar/**","/metodopago/eliminar/**","/descuento/nuevo",
                        "/descuento/modificar/**","/descuento/eliminar/**")
                .hasRole("ADMIN")
                .requestMatchers("/producto/listado",
                        "/categoria/listado",
                        "/usuario/listado")
                .hasAnyRole("ADMIN", "VENDEDOR")
                .requestMatchers("/soporte/listado","/metodopago/listado")
                .hasRole("USER")
                )
                .formLogin((form) -> form
                .loginPage("/login").permitAll())
                .logout((logout) -> logout.permitAll());
        return http.build();
    }


    /* El siguiente método se utiliza para completar la clase no es 
    realmente funcional, se reemplaza con usuarios de BD */
    @Bean
    public UserDetailsService users() {
       UserDetails admin = User.builder()
             .username("marco")
           .password("{noop}123")
         .roles("ADMIN")
         .build();
     UserDetails vendedor = User.builder()
           .username("francella")
         .password("{noop}456")
        .roles("USER", "VENDEDOR")
       .build();
      UserDetails usuario = User.builder()
            .username("user")
          .password("{noop}789")
        .roles("USER")
       .build();
      return new InMemoryUserDetailsManager(admin, vendedor, usuario);
    }

}
