package com.GamerStore.controller;

import com.GamerStore.domain.Descuento;
import com.GamerStore.service.DescuentoService;
import com.GamerStore.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/descuento")
public class DescuentoController {

    @Autowired
    private DescuentoService descuentoService;

    @Autowired
    private ProductoService productoService;

    @GetMapping("/listado")
    public String listado(Model model) {
        var descuentos = descuentoService.getDescuentos(false);
        model.addAttribute("descuentos", descuentos);
        model.addAttribute("totalDescuentos", descuentos.size());
        var productos = productoService.getProductos(false);
        model.addAttribute("productos", productos);
        return "/descuento/listado";
    }

    @GetMapping("/nuevo")
    public String descuentoNuevo(Model model) {
        model.addAttribute("descuento", new Descuento()); // Inicializa el objeto descuento
        var productos = productoService.getProductos(false);
        model.addAttribute("productos", productos);
        return "/descuento/modifica";
    }

    @PostMapping("/guardar")
    public String descuentoGuardar(Descuento descuento) {
        descuentoService.save(descuento);
        return "redirect:/descuento/listado";
    }

    @GetMapping("/eliminar/{idDescuento}")
    public String descuentoEliminar(Descuento descuento) {
        descuentoService.delete(descuento);
        return "redirect:/descuento/listado";
    }

    @GetMapping("/modificar/{idDescuento}")
    public String descuentoModificar(Descuento descuento, Model model) {
        descuento = descuentoService.getDescuento(descuento);
        model.addAttribute("descuento", descuento);
        var productos = productoService.getProductos(false);
        model.addAttribute("productos", productos);
        return "/descuento/modifica";
    }
}
