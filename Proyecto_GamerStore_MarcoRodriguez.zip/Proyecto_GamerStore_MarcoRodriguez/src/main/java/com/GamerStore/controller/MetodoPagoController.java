package com.GamerStore.controller;

import com.GamerStore.domain.MetodoPago;
import com.GamerStore.service.MetodoPagoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/metodopago")
public class MetodoPagoController {

    @Autowired
    private MetodoPagoService metodoPagoService;

    @GetMapping("/listado")
    public String listado(Model model) {
        var metodosPago = metodoPagoService.getMetodosPago(false);
        model.addAttribute("metodosPago", metodosPago);
        model.addAttribute("totalMetodosPago", metodosPago.size());
        return "/metodopago/listado";
    }

    @GetMapping("/nuevo")
    public String metodoPagoNuevo(MetodoPago metodoPago) {
        return "/metodopago/modifica";
    }

    @PostMapping("/guardar")
    public String metodoPagoGuardar(MetodoPago metodoPago) {
        metodoPagoService.save(metodoPago);
        return "redirect:/metodopago/listado";
    }

    @GetMapping("/eliminar/{idMetodoPago}")
    public String metodoPagoEliminar(MetodoPago metodoPago) {
        metodoPagoService.delete(metodoPago);
        return "redirect:/metodopago/listado";
    }

    @GetMapping("/modificar/{idMetodoPago}")
    public String metodoPagoModificar(MetodoPago metodoPago, Model model) {
        metodoPago = metodoPagoService.getMetodoPago(metodoPago);
        model.addAttribute("metodoPago", metodoPago);
        return "/metodopago/modifica";
    }
}

