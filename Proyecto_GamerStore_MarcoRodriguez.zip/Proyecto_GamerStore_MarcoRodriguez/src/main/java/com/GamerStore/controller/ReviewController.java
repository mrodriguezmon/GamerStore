package com.GamerStore.controller;

import com.GamerStore.domain.Review;
import com.GamerStore.service.ProductoService;
import com.GamerStore.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/review")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @Autowired
    private ProductoService productoService;

    @GetMapping("/listado")
    public String listado(Model model) {
        var reviews = reviewService.getReview(false);
        model.addAttribute("reviews", reviews);
        model.addAttribute("totalReviews", reviews.size());
        var productos = productoService.getProductos(false);
        model.addAttribute("productos", productos);
        return "/review/listado";
    }

    @GetMapping("/nuevo")
    public String reviewNuevo(Review review, Model model) {
        var productos = productoService.getProductos(false);
        model.addAttribute("productos", productos);
        return "/review/modifica";
    }

    @PostMapping("/guardar")
    public String reviewGuardar(Review review) {
        reviewService.save(review);
        return "redirect:/review/listado";
    }

    @GetMapping("/eliminar/{idReview}")
    public String reviewEliminar(Review review) {
        reviewService.delete(review);
        return "redirect:/review/listado";
    }

    @GetMapping("/modificar/{idReview}")
    public String reviewModificar(Review review, Model model) {
        review = reviewService.getReview(review);
        model.addAttribute("review", review);
        var productos = productoService.getProductos(false);
        model.addAttribute("productos", productos);
        return "/review/modifica";
    }
}
